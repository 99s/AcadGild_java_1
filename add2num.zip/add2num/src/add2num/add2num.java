package add2num;

public class add2num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub --> what this means? 
		System.out.println("Adding 2 numbers. Int and float \n . Display result as int\n\n");		
		
		
		int numint=10;	
		float numfloat=20.5f;
		
		float float2=numint+numfloat;
		System.out.println("\n\t addition result as float: "+float2);
		int value_int=(int) float2;
		System.out.println("\n\tfloat to int : "+value_int);

	}

}
